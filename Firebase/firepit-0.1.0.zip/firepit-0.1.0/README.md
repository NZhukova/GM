# Firepit - Instant Firebase CLI for Windows

Firepit is a standalone, portable version of the Firebase CLI which has no dependencies (including Node.js). Download, click, and immediately get access to both `firebase` and `npm` commands.

## Downloads
* [Windows (v0.1.0-beta)](http://storage.googleapis.com/fir-tools-builds/firepit/firepit-win-0-1-0-signed.exe)

## Credits
*This is not an official Google product.*
